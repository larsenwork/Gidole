Thanks for downloading!

WANT TO REPOST? COOL, PLEASE
Link to https://gidole.github.io
and/or
Link to latest version https://github.com/gidole/sans/blob/master/gidole.zip?raw=true

CONTRIBUTE
Feedback, ideas, requests etc. https://github.com/gidole/sans/issues
Fork, edit, pull-request https://github.com/gidole/sans/fork

THANKS
@andreaslarsendk